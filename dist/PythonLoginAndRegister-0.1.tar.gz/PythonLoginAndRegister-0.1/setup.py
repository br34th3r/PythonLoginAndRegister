from setuptools import setup

setup(name='PythonLoginAndRegister',
      version='0.1',
      description='Basic Login and Registration in Python',
      url='https://github.com/coolhobo77/Python-Login-And-Register',
      author='coolhobo77',
      author_email='joshuaboddy1@gmail.com',
      license='MIT',
      packages=['src'],
      zip_safe=False)
